"""Incident processing agent: logs -> analysis -> RAG -> remediation -> notification."""
from __future__ import annotations

import asyncio
import fnmatch
import logging
import time
from collections import defaultdict, deque

from app.config import Settings
from app.logging_setup import audit
from app.models import AnalysisReport, GrafanaAlert, IncidentResult, RemediationStatus
from services.ai_analyzer import UNKNOWN, LogAnalyzer
from services.log_reader import LogBundle, read_service_logs
from services.notifier import TeamsNotifier
from services.rag_engine import RagEngine
from services.service_manager import (
    ServiceControlError,
    ServiceState,
    get_service_status,
    restart_service,
)

logger = logging.getLogger("selfhealing.agent")


def _allowed(value: str, patterns: list[str]) -> bool:
    """Deny by default: an empty allow-list permits nothing."""
    return any(fnmatch.fnmatchcase(value.lower(), p.lower()) for p in patterns)


class IncidentAgent:
    def __init__(self, settings: Settings, rag: RagEngine, analyzer: LogAnalyzer, notifier: TeamsNotifier) -> None:
        self._s = settings
        self._rag = rag
        self._analyzer = analyzer
        self._notifier = notifier
        self._restart_history: dict[tuple[str, str], deque[float]] = defaultdict(deque)

    async def handle(self, alert: GrafanaAlert, incident_id: str) -> IncidentResult:
        started = time.monotonic()
        audit("incident_started", incident_id=incident_id, server=alert.server_name,
              service=alert.service_name, alert=alert.alert_name)

        try:
            report = await self._analyse(alert)
        except Exception:  # noqa: BLE001 - analysis failure must not prevent a restart attempt
            logger.exception("analysis_failed")
            report = AnalysisReport(
                service=alert.service_name, root_cause="Log analysis failed", confidence=0.0,
                category=UNKNOWN, sources=["error"],
            )
        logger.info("analysis_complete", extra={"category": report.category, "confidence": report.confidence,
                                                "recoverable": report.recoverable, "summary": report.summary()})

        action, state, status = await self._remediate(alert, report)

        result = IncidentResult(
            incident_id=incident_id, alert=alert, analysis=report, action_taken=action,
            service_status=state.value, remediation_status=status,
            time_taken_seconds=round(time.monotonic() - started, 1),
        )
        audit("incident_finished", incident_id=incident_id, server=alert.server_name, service=alert.service_name,
              category=report.category, action=action, service_status=state.value,
              remediation_status=status.value, seconds=result.time_taken_seconds)

        await self._notifier.send_incident(result)
        await self._learn(result)
        return result

    # ------------------------------------------------------------------ steps 2-4
    async def _analyse(self, alert: GrafanaAlert) -> AnalysisReport:
        bundle: LogBundle = await asyncio.to_thread(
            read_service_logs, alert.service_name, alert.server_name, self._s.search_paths,
            self._s.log_max_lines, self._s.log_search_depth, self._s.log_max_files,
        )
        report = self._analyzer.analyze(alert.service_name, bundle.lines)
        if self._rag.enabled and bundle.lines:
            hits = await asyncio.to_thread(self._rag.search, self._analyzer.build_rag_query(report))
            report = self._analyzer.apply_rag_hits(report, hits)
        return report

    # ------------------------------------------------------------------ step 5
    async def _remediate(self, alert: GrafanaAlert, report: AnalysisReport) -> tuple[str, ServiceState, RemediationStatus]:
        svc, srv = alert.service_name, alert.server_name

        try:
            state = await asyncio.to_thread(get_service_status, svc, srv)
        except ServiceControlError as exc:
            return f"Status check failed: {exc}", ServiceState.UNKNOWN, RemediationStatus.FAILED

        if state == ServiceState.RUNNING:
            return "No action needed - service is already running", state, RemediationStatus.SUCCESS

        recoverable = report.recoverable or (report.category == UNKNOWN and self._s.restart_unknown_causes)
        if not recoverable:
            return (f"No automatic restart - '{report.category}' is not recoverable by restart; "
                    "manual intervention required"), state, RemediationStatus.FAILED
        if not (_allowed(svc, self._s.allowed_service_patterns) and _allowed(srv, self._s.allowed_server_patterns)):
            audit("remediation_blocked_allowlist", server=srv, service=svc)
            return "Restart blocked - service/server is not in the remediation allow-list", state, RemediationStatus.FAILED
        if not self._restart_budget_ok(srv, svc):
            audit("remediation_blocked_rate_limit", server=srv, service=svc)
            return (f"Restart skipped - limit of {self._s.max_restarts_per_hour} restarts/hour reached "
                    "(possible restart loop)"), state, RemediationStatus.FAILED
        if self._s.dry_run:
            return "Dry-run: restart would have been performed", state, RemediationStatus.FAILED

        audit("restart_attempt", server=srv, service=svc, category=report.category)
        action = "Restarted service"
        try:
            await asyncio.to_thread(restart_service, svc, srv)
        except ServiceControlError as exc:
            action = f"Restart attempted but failed: {exc}"

        await asyncio.sleep(self._s.restart_wait_seconds)  # allow the service to finish starting
        try:
            state = await asyncio.to_thread(get_service_status, svc, srv)
        except ServiceControlError:
            state = ServiceState.UNKNOWN

        status = RemediationStatus.SUCCESS if state == ServiceState.RUNNING else RemediationStatus.FAILED
        return f"{action}; waited {self._s.restart_wait_seconds}s and re-checked status", state, status

    def _restart_budget_ok(self, server: str, service: str) -> bool:
        history = self._restart_history[(server.lower(), service.lower())]
        now = time.monotonic()
        while history and now - history[0] > 3600:
            history.popleft()
        if len(history) >= self._s.max_restarts_per_hour:
            return False
        history.append(now)
        return True

    # ------------------------------------------------------------------ knowledge loop
    async def _learn(self, r: IncidentResult) -> None:
        try:
            await asyncio.to_thread(
                self._rag.record_incident, server=r.alert.server_name, service=r.alert.service_name,
                category=r.analysis.category, root_cause=r.analysis.root_cause,
                action_taken=r.action_taken, outcome=r.remediation_status.value, evidence=r.analysis.evidence,
            )
        except Exception:  # noqa: BLE001
            logger.exception("incident_recording_failed")
