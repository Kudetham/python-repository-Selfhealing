<#
.SYNOPSIS
  Builds a self-contained SelfHealingAgent folder (no Python needed on the target server).
  Run on a build machine from the project root venv. Output: dist\SelfHealingAgent\
#>
$ErrorActionPreference = 'Stop'
$AppRoot = Split-Path -Parent $PSScriptRoot
Set-Location $AppRoot
$Py = Join-Path $AppRoot '.venv\Scripts\python.exe'

& $Py -m pip install pyinstaller
& $Py -m PyInstaller --noconfirm --clean --onedir --name SelfHealingAgent `
    --collect-submodules uvicorn `
    --hidden-import win32timezone --hidden-import servicemanager `
    --paths $AppRoot `
    windows_service\selfhealing_service.py
if ($LASTEXITCODE -ne 0) { throw 'PyInstaller failed' }

$Out = Join-Path $AppRoot 'dist\SelfHealingAgent'
Copy-Item -Recurse -Force (Join-Path $AppRoot 'knowledge_base') $Out
Copy-Item -Force (Join-Path $AppRoot '.env.example') $Out
Copy-Item -Force (Join-Path $AppRoot 'scripts\install_exe_service.ps1') $Out
Write-Host "Built: $Out  (copy this whole folder to the server, add .env, run install_exe_service.ps1)"
