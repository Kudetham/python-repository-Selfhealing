"""Structured JSON logging with rotation, plus a separate audit trail."""
from __future__ import annotations

import contextvars
import json
import logging
import sys
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path

from app.config import PROJECT_ROOT, Settings

# Correlates every log line of one incident (propagates into asyncio tasks and to_thread).
incident_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("incident_id", default="-")

_STD_ATTRS = set(logging.LogRecord("", 0, "", 0, "", (), None).__dict__) | {"message", "asctime", "taskName"}
_configured = False


class JsonFormatter(logging.Formatter):
    """One JSON object per line. json.dumps escapes newlines, which prevents log forging."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, object] = {
            "ts": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "logger": record.name,
            "incident_id": incident_id_var.get(),
            "message": record.getMessage(),
        }
        for key, value in record.__dict__.items():
            if key not in _STD_ATTRS and not key.startswith("_"):
                payload[key] = value
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str, ensure_ascii=False)


def _resolve_log_dir(preferred: Path) -> Path:
    try:
        preferred.mkdir(parents=True, exist_ok=True)
        return preferred
    except OSError:
        fallback = PROJECT_ROOT / "logs"
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback


def _file_handler(path: Path, max_mb: int, backups: int) -> RotatingFileHandler:
    handler = RotatingFileHandler(path, maxBytes=max_mb * 1024 * 1024, backupCount=backups, encoding="utf-8")
    handler.setFormatter(JsonFormatter())
    return handler


def setup_logging(settings: Settings) -> None:
    """Idempotent. Creates ``agent.log`` (application) and ``audit.log`` (security/remediation trail)."""
    global _configured
    if _configured:
        return
    log_dir = _resolve_log_dir(settings.log_dir)
    level = getattr(logging, settings.log_level.upper(), logging.INFO)

    app_logger = logging.getLogger("selfhealing")
    app_logger.setLevel(level)
    app_logger.addHandler(_file_handler(log_dir / "agent.log", max_mb=10, backups=10))
    console = logging.StreamHandler(sys.stderr)
    console.setFormatter(JsonFormatter())
    app_logger.addHandler(console)

    audit_logger = logging.getLogger("selfhealing.audit")
    audit_logger.setLevel(logging.INFO)
    audit_logger.addHandler(_file_handler(log_dir / "audit.log", max_mb=20, backups=30))
    audit_logger.propagate = False  # audit records go only to audit.log

    _configured = True
    app_logger.info("logging_initialised", extra={"log_dir": str(log_dir)})


def audit(event: str, **fields: object) -> None:
    """Write an immutable-style audit record. Never pass secrets in ``fields``."""
    logging.getLogger("selfhealing.audit").info(event, extra={"audit": fields})
