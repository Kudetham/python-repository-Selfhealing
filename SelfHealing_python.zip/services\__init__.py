"""Domain services: webhook, log reader, service manager, AI analyzer, RAG engine, notifier."""
