"""Discovers and tails service log files on shared network paths."""
from __future__ import annotations

import codecs
import logging
import os
import re
from dataclasses import dataclass, field

logger = logging.getLogger("selfhealing.log_reader")

_LOG_EXTENSIONS = {".log", ".txt", ".out", ".err"}
_CHUNK_BYTES = 64 * 1024
_MAX_UTF16_BYTES = 32 * 1024 * 1024
_MAX_LINE_CHARS = 2000

# Logs are forwarded to Teams and the RAG index, so credentials are scrubbed at read time.
_REDACTIONS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"(?i)\b(password|pwd|passwd|secret|api[_-]?key|token|accountkey|sharedaccesssignature)\s*[=:]\s*[^;\s,\"']+"), r"\1=***"),
    (re.compile(r"(?i)\bBearer\s+[A-Za-z0-9\-._~+/]+=*"), "Bearer ***"),
]


@dataclass(frozen=True)
class LogBundle:
    service_name: str
    server_name: str
    lines: list[str] = field(default_factory=list)
    files: list[str] = field(default_factory=list)


def redact(line: str) -> str:
    for pattern, repl in _REDACTIONS:
        line = pattern.sub(repl, line)
    return line


def _matches_service(rel_path: str, service_name: str) -> bool:
    haystack = rel_path.lower()
    needle = service_name.lower()
    return needle in haystack or needle.replace(" ", "") in haystack.replace(" ", "")


def find_log_files(
    service_name: str, server_name: str, search_paths: list[str], max_depth: int, max_files: int
) -> list[str]:
    """Return candidate log files, newest first (files mentioning the server rank higher)."""
    candidates: list[tuple[bool, float, str]] = []
    server_l = server_name.lower()

    for root in search_paths:
        if not os.path.isdir(root):
            logger.warning("log_path_unavailable", extra={"path": root})
            continue
        # followlinks=False (default) avoids escaping the share through reparse points.
        for dirpath, dirnames, filenames in os.walk(root):
            rel = os.path.relpath(dirpath, root)
            depth = 0 if rel == "." else rel.count(os.sep) + 1
            if depth >= max_depth:
                dirnames[:] = []
            for name in filenames:
                if os.path.splitext(name)[1].lower() not in _LOG_EXTENSIONS:
                    continue
                rel_file = os.path.join(rel, name) if rel != "." else name
                if not _matches_service(rel_file, service_name):
                    continue
                full = os.path.join(dirpath, name)
                try:
                    mtime = os.path.getmtime(full)
                except OSError:
                    continue
                candidates.append((server_l in rel_file.lower(), mtime, full))

    candidates.sort(key=lambda c: (c[0], c[1]), reverse=True)
    return [c[2] for c in candidates[:max_files]]


def _tail_lines(path: str, n: int) -> list[str]:
    """Read the last ``n`` lines without loading the whole file (UTF-8/ANSI and UTF-16 aware)."""
    with open(path, "rb") as fh:
        head = fh.read(2)
        fh.seek(0, os.SEEK_END)
        size = fh.tell()

        if head in (codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE):
            encoding = "utf-16-le" if head == codecs.BOM_UTF16_LE else "utf-16-be"
            start = max(2, size - _MAX_UTF16_BYTES)
            start -= start % 2  # keep code-unit alignment
            start = max(start, 2)
            fh.seek(start)
            text = fh.read().decode(encoding, errors="replace")
            lines = text.splitlines()
        else:
            pos, data = size, b""
            while pos > 0 and data.count(b"\n") <= n:
                step = min(_CHUNK_BYTES, pos)
                pos -= step
                fh.seek(pos)
                data = fh.read(step) + data
            lines = [raw.decode("utf-8", errors="replace") for raw in data.splitlines()]

    return [ln.lstrip("\ufeff")[:_MAX_LINE_CHARS] for ln in lines[-n:] if ln.strip()]


def read_service_logs(
    service_name: str,
    server_name: str,
    search_paths: list[str],
    max_lines: int = 1000,
    max_depth: int = 3,
    max_files: int = 5,
) -> LogBundle:
    """Collect the last ``max_lines`` lines for a service, spilling into older files if needed."""
    files = find_log_files(service_name, server_name, search_paths, max_depth, max_files)
    chunks: list[list[str]] = []  # newest file first
    used: list[str] = []
    remaining = max_lines

    for path in files:
        if remaining <= 0:
            break
        try:
            tail = _tail_lines(path, remaining)
        except OSError as exc:
            logger.warning("log_read_failed", extra={"file": path, "error": type(exc).__name__})
            continue
        if tail:
            chunks.append([redact(ln) for ln in tail])
            used.append(path)
            remaining -= len(tail)

    # Chronological order: oldest file first.
    lines = [ln for chunk in reversed(chunks) for ln in chunk]
    logger.info(
        "logs_collected",
        extra={"service": service_name, "server": server_name, "line_count": len(lines), "files": used},
    )
    return LogBundle(service_name, server_name, lines, used)
