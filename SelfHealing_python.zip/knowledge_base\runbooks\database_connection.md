---
title: Database Connection Failure Runbook
category: DATABASE_CONNECTION
recoverable: true
root_cause: Database unreachable, SQL timeout or exhausted connection pool
---
## Symptoms
SQL timeout, "Timeout expired", "A network-related or instance-specific error occurred while establishing a connection to SQL Server", connection pool exhausted, deadlock victim.

## Diagnosis
1. Test connectivity from the app server: `Test-NetConnection <dbhost> -Port 1433`.
2. Check the SQL Server service and Always On / failover state.
3. Look for blocking sessions or long running queries.

## Resolution
Restart the application service to rebuild stale connection pools once the database is reachable. If the database is down, escalate to the DBA team; a restart alone will loop.
