---
title: File Access Runbook
category: FILE_ACCESS
recoverable: false
root_cause: Missing path, NTFS/share permission problem, locked file or full disk
---
## Symptoms
"Access to the path ... is denied", UnauthorizedAccessException, FileNotFoundException, "used by another process", disk full.

## Diagnosis
1. `icacls <path>` for the service account permissions.
2. `Get-PSDrive C` for free space; check share availability.
3. Use Resource Monitor / handle.exe to find the process locking the file.

## Resolution
Fix permissions, free disk space or release the lock first. A blind restart will fail again.
