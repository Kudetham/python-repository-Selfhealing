<#
.SYNOPSIS
  Stops and removes the Self-Healing Agent Windows service. Run elevated.
#>
$ErrorActionPreference = 'Stop'
$AppRoot = Split-Path -Parent $PSScriptRoot
$Py = Join-Path $AppRoot '.venv\Scripts\python.exe'

if (Get-Service SelfHealingAgent -ErrorAction SilentlyContinue) {
    Stop-Service SelfHealingAgent -Force -ErrorAction SilentlyContinue
    & $Py (Join-Path $AppRoot 'windows_service\selfhealing_service.py') remove
}
Remove-NetFirewallRule -DisplayName 'SelfHealingAgent Webhook' -ErrorAction SilentlyContinue
Write-Host 'Service removed. Logs and index under C:\SelfHealingAgent were kept.'
