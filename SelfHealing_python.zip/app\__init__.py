"""Self-healing agent application package."""
