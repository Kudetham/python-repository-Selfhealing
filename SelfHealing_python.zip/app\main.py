"""FastAPI application entry point.  Run: ``uvicorn app.main:app`` (single worker)."""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.config import get_settings
from app.incident_agent import IncidentAgent
from app.logging_setup import audit, setup_logging
from services.ai_analyzer import LogAnalyzer
from services.notifier import TeamsNotifier
from services.rag_engine import RagEngine
from services.webhook import router as webhook_router

MAX_BODY_BYTES = 64 * 1024
logger = logging.getLogger("selfhealing.app")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    settings = get_settings()
    setup_logging(settings)
    rag = RagEngine(settings)
    await asyncio.to_thread(rag.initialize)  # may call Azure OpenAI; keep it off the event loop
    app.state.agent = IncidentAgent(settings, rag, LogAnalyzer(), TeamsNotifier(settings))
    if settings.api_key is None:
        logger.warning("api_key_not_set_webhook_authentication_disabled")
    audit("service_started", rag_enabled=rag.enabled, dry_run=settings.dry_run, auth_enabled=settings.api_key is not None)
    yield
    audit("service_stopped")


# Interactive docs/OpenAPI are disabled: this is an internal automation endpoint.
app = FastAPI(title="Self-Healing Agent", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
app.include_router(webhook_router)


@app.middleware("http")
async def limit_body_size(request: Request, call_next):  # type: ignore[no-untyped-def]
    length = request.headers.get("content-length")
    if length and length.isdigit() and int(length) > MAX_BODY_BYTES:
        return JSONResponse(status_code=413, content={"detail": "Payload too large"})
    return await call_next(request)


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    # Return only field + message; the default handler echoes the submitted input back.
    errors = [{"loc": [str(p) for p in e["loc"]], "msg": e["msg"]} for e in exc.errors()]
    client = request.client.host if request.client else "unknown"
    logger.warning("payload_validation_failed", extra={"client": client, "errors": errors})
    audit("payload_rejected", client=client, errors=errors)
    return JSONResponse(status_code=422, content={"detail": errors})


@app.exception_handler(Exception)
async def unhandled_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.exception("unhandled_exception", extra={"path": request.url.path})
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


@app.get("/health", include_in_schema=False)
async def health() -> dict[str, str]:
    return {"status": "ok"}
