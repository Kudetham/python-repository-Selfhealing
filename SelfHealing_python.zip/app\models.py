"""Pydantic models shared across the application."""
from __future__ import annotations

import re
from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

# Allow-list validation: these values flow into file globbing and service control calls,
# so path separators, quotes and control characters are rejected outright.
_SERVER_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.\-]{0,252}$")
_SERVICE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.\-$ ]{0,255}$")
_NO_CONTROL_CHARS = re.compile(r"^[^\x00-\x1f\x7f]+$")  # blocks log forging via CR/LF


class RemediationStatus(str, Enum):
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"


class GrafanaAlert(BaseModel):
    """Payload sent by the Grafana webhook contact point."""

    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    server_name: str
    service_name: str
    alert_name: str = Field(min_length=1, max_length=256)
    timestamp: datetime

    @field_validator("server_name")
    @classmethod
    def _check_server(cls, v: str) -> str:
        if not _SERVER_RE.fullmatch(v):
            raise ValueError("invalid server_name")
        return v

    @field_validator("service_name")
    @classmethod
    def _check_service(cls, v: str) -> str:
        if not _SERVICE_RE.fullmatch(v):
            raise ValueError("invalid service_name")
        return v

    @field_validator("alert_name")
    @classmethod
    def _check_alert(cls, v: str) -> str:
        if not _NO_CONTROL_CHARS.fullmatch(v):
            raise ValueError("invalid alert_name")
        return v


class AcceptedResponse(BaseModel):
    incident_id: str
    status: str


class AnalysisReport(BaseModel):
    """Root cause summary. ``summary()`` returns the minimal 4-field contract."""

    service: str
    root_cause: str
    confidence: float = Field(ge=0.0, le=1.0)
    evidence: list[str] = Field(default_factory=list)

    category: str = "UNKNOWN"
    recoverable: bool = False
    recommended_action: str = ""
    runbook: str | None = None
    suggested_resolution: str | None = None
    clusters: list[dict[str, Any]] = Field(default_factory=list)
    temporal: dict[str, Any] = Field(default_factory=dict)
    correlations: list[str] = Field(default_factory=list)
    sources: list[str] = Field(default_factory=list)

    def summary(self) -> dict[str, Any]:
        return {
            "service": self.service,
            "root_cause": self.root_cause,
            "confidence": self.confidence,
            "evidence": self.evidence,
        }


class IncidentResult(BaseModel):
    incident_id: str
    alert: GrafanaAlert
    analysis: AnalysisReport
    action_taken: str
    service_status: str
    remediation_status: RemediationStatus
    time_taken_seconds: float
