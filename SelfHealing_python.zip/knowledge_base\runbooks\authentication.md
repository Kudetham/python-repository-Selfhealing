---
title: Authentication Failure Runbook
category: AUTHENTICATION
recoverable: false
root_cause: Service account credentials invalid, expired or locked
---
## Symptoms
Login failed for user, logon failure, "The user name or password is incorrect", 401 Unauthorized, access denied for user.

## Diagnosis
1. Check the service "Log On As" account in services.msc.
2. Check AD for locked/expired accounts and recent password rotations.
3. Verify secrets/connection strings were updated after rotation.

## Resolution
Do NOT restart; it will fail again and may lock the account. Reset or update the credentials, then start the service manually.
