r"""Hosts the FastAPI app (uvicorn) as a native Windows service.

Install   : python windows_service\selfhealing_service.py --startup auto install
Start/stop: python windows_service\selfhealing_service.py start | stop
Remove    : python windows_service\selfhealing_service.py remove
Console   : python windows_service\selfhealing_service.py console   (foreground, for testing)

The same script is built into SelfHealingAgent.exe by scripts\build_exe.ps1.
"""
import os
import sys
from pathlib import Path

import servicemanager
import win32event
import win32service
import win32serviceutil

PROJECT_ROOT = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent.parent


def _build_server():  # type: ignore[no-untyped-def]
    import uvicorn

    from app.config import get_settings
    from app.main import app

    s = get_settings()
    config = uvicorn.Config(
        app, host=s.host, port=s.port, workers=1,  # single worker: in-memory dedupe/rate limit
        log_config=None,  # our JSON logging is configured by the app
        ssl_certfile=s.tls_certfile or None, ssl_keyfile=s.tls_keyfile or None,
    )
    return uvicorn.Server(config)


class SelfHealingService(win32serviceutil.ServiceFramework):
    _svc_name_ = "SelfHealingAgent"
    _svc_display_name_ = "AI Self-Healing Agent"
    _svc_description_ = "Receives Grafana alerts, analyses logs and restarts failed Windows services."

    def __init__(self, args):
        super().__init__(args)
        self._stop_event = win32event.CreateEvent(None, 0, 0, None)
        self._server = None

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        if self._server is not None:
            self._server.should_exit = True  # uvicorn finishes in-flight requests, then returns
        win32event.SetEvent(self._stop_event)

    def SvcDoRun(self):
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE, servicemanager.PYS_SERVICE_STARTED, (self._svc_name_, "")
        )
        # The service starts with CWD=System32; make project imports and relative paths work.
        os.chdir(PROJECT_ROOT)
        sys.path.insert(0, str(PROJECT_ROOT))
        try:
            self._server = _build_server()
            self._server.run()
        except Exception as exc:  # surface startup failures in the Windows Event Log
            servicemanager.LogErrorMsg(f"{self._svc_name_} crashed: {exc!r}")
            raise
        finally:
            servicemanager.LogMsg(
                servicemanager.EVENTLOG_INFORMATION_TYPE, servicemanager.PYS_SERVICE_STOPPED, (self._svc_name_, "")
            )


if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[1] == "console":
        os.chdir(PROJECT_ROOT)
        sys.path.insert(0, str(PROJECT_ROOT))
        _build_server().run()
    elif len(sys.argv) == 1:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(SelfHealingService)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        win32serviceutil.HandleCommandLine(SelfHealingService)
