"""API key authentication for the Grafana webhook."""
from __future__ import annotations

import secrets

from fastapi import Header, HTTPException, Request, status

from app.config import get_settings
from app.logging_setup import audit


def _extract_key(x_api_key: str | None, authorization: str | None) -> str | None:
    """Accept ``X-API-Key: <key>`` or ``Authorization: Bearer <key>`` (Grafana supports both)."""
    if x_api_key:
        return x_api_key
    if authorization and authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return None


async def verify_api_key(
    request: Request,
    x_api_key: str | None = Header(default=None),
    authorization: str | None = Header(default=None),
) -> None:
    api_key = get_settings().api_key
    if api_key is None:
        return  # authentication disabled (SH_API_KEY not set)
    expected = api_key.get_secret_value().encode("utf-8")
    supplied = _extract_key(x_api_key, authorization)
    client = request.client.host if request.client else "unknown"

    # compare_digest on bytes: constant-time and safe for non-ASCII input.
    if supplied is None or not secrets.compare_digest(supplied.encode("utf-8"), expected):
        audit("auth_failed", client=client, path=request.url.path)
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or missing API key")
