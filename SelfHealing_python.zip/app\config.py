"""Central configuration loaded from environment variables (prefix ``SH_``) and ``.env``."""
from __future__ import annotations

import sys
from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Frozen (PyInstaller) build: .env and knowledge_base/ live next to the exe.
PROJECT_ROOT = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent.parent


def _split(value: str, sep: str) -> list[str]:
    return [item.strip() for item in value.split(sep) if item.strip()]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="SH_",
        # Absolute path so the Windows service (whose CWD is System32) still finds it.
        env_file=PROJECT_ROOT / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- API / security ---
    api_key: SecretStr | None = None  # unset/empty disables webhook authentication (local testing only)
    host: str = "0.0.0.0"
    port: int = Field(default=8080, ge=1, le=65535)
    tls_certfile: str | None = None
    tls_keyfile: str | None = None

    # --- Logging ---
    log_dir: Path = Path(r"C:\SelfHealingAgent\Logs")
    log_level: str = "INFO"

    # --- Log discovery ---
    log_search_paths: str = r"\\sharedlogs\ApplicationLogs;\\sharedlogs\ServiceLogs"
    log_max_lines: int = Field(default=1000, ge=50, le=20000)
    log_search_depth: int = Field(default=3, ge=0, le=8)
    log_max_files: int = Field(default=5, ge=1, le=20)

    # --- Remediation ---
    allowed_services: str = ""
    allowed_servers: str = ""
    service_backend: Literal["auto", "pywin32", "powershell"] = "auto"
    service_op_timeout: int = Field(default=60, ge=5, le=600)
    restart_wait_seconds: int = Field(default=30, ge=0, le=600)
    max_restarts_per_hour: int = Field(default=3, ge=1, le=20)
    restart_unknown_causes: bool = False
    dry_run: bool = False

    # --- Teams ---
    teams_webhook_url: SecretStr | None = None
    teams_timeout_seconds: float = 10.0
    teams_max_retries: int = Field(default=4, ge=1, le=10)

    # --- Azure OpenAI / RAG ---
    azure_openai_endpoint: str | None = None
    azure_openai_api_key: SecretStr | None = None
    azure_openai_api_version: str = "2024-02-01"
    azure_openai_embedding_deployment: str = "text-embedding-3-small"
    kb_dir: Path = PROJECT_ROOT / "knowledge_base"
    rag_index_dir: Path = Path(r"C:\SelfHealingAgent\Index")
    rag_top_k: int = Field(default=4, ge=1, le=20)
    rag_min_score: float = Field(default=0.35, ge=0.0, le=1.0)

    @field_validator("api_key", mode="before")
    @classmethod
    def _api_key_strength(cls, v: object) -> object:
        if v is None or (isinstance(v, str) and not v.strip()):
            return None
        if isinstance(v, str) and len(v) < 16:
            raise ValueError("SH_API_KEY must be at least 16 characters")
        return v

    @property
    def search_paths(self) -> list[str]:
        return _split(self.log_search_paths, ";")

    @property
    def allowed_service_patterns(self) -> list[str]:
        return _split(self.allowed_services, ",")

    @property
    def allowed_server_patterns(self) -> list[str]:
        return _split(self.allowed_servers, ",")

    @property
    def rag_configured(self) -> bool:
        return bool(self.azure_openai_endpoint and self.azure_openai_api_key)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]  # values come from the environment
