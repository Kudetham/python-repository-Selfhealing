---
title: Network Connectivity Runbook
category: NETWORK
recoverable: true
root_cause: Dependency unreachable (connection refused/reset, DNS or routing failure)
---
## Symptoms
Connection refused, connection reset, no route to host, "actively refused it", DNS resolution failures.

## Diagnosis
1. `Test-NetConnection <host> -Port <port>` and `Resolve-DnsName <host>`.
2. Check Windows Firewall and network ACLs between the servers.
3. Confirm the dependency service is listening (`netstat -ano`).

## Resolution
Restore connectivity, then restart the service so it re-establishes its connections.
