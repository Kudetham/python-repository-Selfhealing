---
title: Out Of Memory Runbook
category: OUT_OF_MEMORY
recoverable: true
root_cause: Process exhausted available memory (leak or undersized host)
---
## Symptoms
OutOfMemoryException, java.lang.OutOfMemoryError, "Insufficient memory", GC overhead limit exceeded.

## Diagnosis
1. Check working set growth: `Get-Process <name> | Select WS, PM`.
2. Review recent deployments and large batch jobs.

## Resolution
Restart the service to release memory. If it recurs within hours, raise the memory limit / heap size and open a defect for the leak.
