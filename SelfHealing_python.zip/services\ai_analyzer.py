"""Log analysis: regex pattern detection, error clustering, temporal analysis, failure correlation.

Pipeline:  parse lines -> classify (regex) -> cluster errors -> temporal profile
           -> correlate failure chain -> score categories -> root-cause report.
RAG hits (see rag_engine) can then refine the report via ``apply_rag_hits``.
"""
from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime
from difflib import SequenceMatcher
from typing import TYPE_CHECKING, Any

from app.models import AnalysisReport

if TYPE_CHECKING:  # avoid importing LangChain just for typing
    from services.rag_engine import RagHit

UNKNOWN = "UNKNOWN"


# ----------------------------------------------------------------------------- failure patterns
@dataclass(frozen=True)
class FailurePattern:
    category: str
    root_cause: str
    recommended_action: str
    recoverable: bool  # whether a service restart is a reasonable first remediation
    symptom_rank: int  # 0 = usually a root cause ... 3 = usually a downstream symptom
    rules: tuple[tuple[re.Pattern[str], float], ...]  # (regex, specificity weight)


def _p(category: str, root_cause: str, action: str, recoverable: bool, rank: int,
       rules: list[tuple[str, float]]) -> FailurePattern:
    return FailurePattern(
        category, root_cause, action, recoverable, rank,
        tuple((re.compile(rx, re.IGNORECASE), w) for rx, w in rules),
    )


_PATH_HINT = r"(?:[A-Za-z]:\\|\\\\|\bfile\b|\bpath\b|\bfolder\b|\bdirectory\b)"

PATTERNS: tuple[FailurePattern, ...] = (
    _p("OUT_OF_MEMORY", "Process ran out of memory (OutOfMemoryException / heap exhaustion)",
       "Restart the service; investigate memory leak or raise memory limits", True, 0, [
        (r"OutOfMemoryException|java\.lang\.OutOfMemoryError", 1.0),
        (r"out of memory|insufficient memory|not enough (?:storage|memory)", 0.9),
        (r"memory allocation (?:failed|error)|GC overhead limit exceeded", 0.9),
    ]),
    _p("PORT_CONFLICT", "Listening port is already in use by another process",
       "Identify the process holding the port (netstat -ano); restart the service once it is freed", True, 0, [
        (r"address already in use|port \d+ (?:is )?already (?:in use|being used)", 1.0),
        (r"only one usage of each socket address|EADDRINUSE|SocketException.*10048", 1.0),
        (r"failed to bind|bind(?:ing)? (?:failed|error)", 0.8),
    ]),
    _p("SSL_CERTIFICATE", "TLS/SSL certificate problem (expired, untrusted or invalid)",
       "Renew or re-bind the certificate; a restart will not fix this", False, 0, [
        (r"certificate (?:has )?expired|certificate is expired|certificate not yet valid", 1.0),
        (r"CERTIFICATE_VERIFY_FAILED|x509|untrusted root|remote certificate is invalid", 0.95),
        (r"could not establish trust relationship for the SSL/TLS|certificate (?:verif|validat)\w+ failed", 0.95),
        (r"\bssl\b.{0,30}(?:error|exception|handshake)|\btls\b.{0,30}(?:error|handshake)", 0.7),
    ]),
    _p("FILE_ACCESS", "File or directory access problem (permissions, missing path, locked file or full disk)",
       "Fix NTFS/share permissions, free disk space or release the file lock", False, 0, [
        (rf"access to the path .* is denied|access (?:is )?denied.*{_PATH_HINT}|{_PATH_HINT}.*access (?:is )?denied", 1.0),
        (r"UnauthorizedAccessException|permission denied", 0.95),
        (r"used by another process|could not find (?:file|a part of the path)|no such file or directory", 0.9),
        (r"FileNotFoundException|DirectoryNotFoundException|disk (?:is )?full|not enough space on the disk", 0.9),
    ]),
    _p("AUTHENTICATION", "Authentication or authorisation failure (bad/expired credentials or denied access)",
       "Verify and rotate the service account credentials; a restart will not fix this", False, 0, [
        (r"logon failure|the user name or password is incorrect|authentication failed", 1.0),
        (r"login failed for user|invalid (?:credentials|password|token)|access denied for user", 0.95),
        (r"unauthori[sz]ed|(?:status|http|code)\D{0,12}401\b|kerberos|account (?:is )?(?:locked|disabled|expired)", 0.8),
        (r"access (?:is )?denied", 0.7),
    ]),
    _p("NETWORK", "Network connectivity problem (connection refused/reset, DNS or routing failure)",
       "Verify network path, DNS and firewall to the dependency; restart the service once reachable", True, 1, [
        (r"actively refused it|WSAECONNREFUSED|no route to host|network (?:is )?unreachable", 0.95),
        (r"connection (?:was )?(?:refused|reset|aborted|closed unexpectedly)", 0.85),
        (r"could not resolve host|name or service not known|host (?:not found|unreachable)|dns", 0.8),
        (r"connection timed out|socket\s?exception|network error", 0.75),
    ]),
    _p("DATABASE_CONNECTION", "Database connection failure (SQL timeout, unreachable or exhausted pool)",
       "Verify database availability and connection pool; restart the service to rebuild connections", True, 2, [
        (r"a network-related or instance-specific error occurred while establishing a connection to sql server", 1.0),
        (r"sql\s?(?:server )?time\s?out|timeout expired|SqlException|cannot open database", 0.95),
        (r"could not (?:open|establish) (?:a )?connection to (?:the )?(?:database|sql)|ORA-\d{5}", 0.95),
        (r"deadlock victim|connection pool|database (?:is )?(?:unavailable|offline)|ODBC.*(?:failed|error)", 0.8),
    ]),
    _p("STARTUP_FAILURE", "Service failed to start or terminated unexpectedly during initialisation",
       "Restart the service and review the startup exception", True, 3, [
        (r"failed to start|unable to start|service (?:terminated|stopped) unexpectedly", 0.9),
        (r"startup (?:failed|error)|error 1053|fatal error during (?:start|initiali[sz]ation)", 0.9),
        (r"timeout .* waiting for .* service to (?:start|connect)|unhandled exception", 0.7),
    ]),
)
_PATTERN_BY_CATEGORY = {p.category: p for p in PATTERNS}


# ----------------------------------------------------------------------------- line parsing
_TS_RE = re.compile(r"(?P<ts>\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:[.,]\d{1,6})?)")  # ISO-style only
_LEVEL_RE = re.compile(r"\b(TRACE|DEBUG|INFO|INFORMATION|WARN|WARNING|ERROR|ERR|FATAL|CRITICAL)\b", re.IGNORECASE)
_LEVEL_ALIAS = {"INFORMATION": "INFO", "WARNING": "WARN", "ERR": "ERROR", "CRITICAL": "FATAL"}
_LEVEL_WEIGHT: dict[str | None, float] = {
    "FATAL": 1.3, "ERROR": 1.0, "WARN": 0.7, None: 0.8, "INFO": 0.5, "DEBUG": 0.3, "TRACE": 0.3,
}


@dataclass
class _Line:
    idx: int
    raw: str
    ts: datetime | None
    level: str | None
    category: str | None
    weight: float

    @property
    def is_error(self) -> bool:
        if self.level in ("ERROR", "FATAL"):
            return True
        return self.category is not None and self.level not in ("DEBUG", "TRACE")


def _parse_ts(text: str) -> datetime | None:
    m = _TS_RE.search(text)
    if not m:
        return None
    try:
        return datetime.fromisoformat(m.group("ts").replace(",", ".").replace(" ", "T"))
    except ValueError:
        return None


def _classify(text: str) -> tuple[str, float] | None:
    """Assign a line to its single best-matching category (highest specificity wins)."""
    best: tuple[str, float] | None = None
    for pattern in PATTERNS:
        for rx, weight in pattern.rules:
            if rx.search(text) and (best is None or weight > best[1]):
                best = (pattern.category, weight)
    return best


def _parse_lines(lines: list[str]) -> list[_Line]:
    parsed: list[_Line] = []
    for idx, raw in enumerate(lines):
        m = _LEVEL_RE.search(raw[:120])
        level = m.group(1).upper() if m else None
        level = _LEVEL_ALIAS.get(level, level) if level else None
        hit = _classify(_TS_RE.sub("", raw, count=1))  # strip timestamp so ".401" ms is not read as HTTP 401
        parsed.append(_Line(idx, raw, _parse_ts(raw), level, hit[0] if hit else None, hit[1] if hit else 0.0))
    return parsed


# ----------------------------------------------------------------------------- error clustering
_NORMALIZERS: tuple[tuple[re.Pattern[str], str], ...] = (
    (_TS_RE, ""),
    (re.compile(r"\b[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\b", re.I), "<guid>"),
    (re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?\b"), "<ip>"),
    (re.compile(r"\b0x[0-9a-f]+\b", re.I), "<hex>"),
    (re.compile(r"[A-Za-z]:\\[^\s\"']+|\\\\[^\s\"']+"), "<path>"),
    (re.compile(r"\d+"), "<n>"),
)


def _signature(raw: str) -> str:
    text = raw
    for rx, repl in _NORMALIZERS:
        text = rx.sub(repl, text)
    return " ".join(text.lower().split())[:300]


@dataclass
class ErrorCluster:
    signature: str
    count: int
    first_idx: int
    last_idx: int
    first_ts: datetime | None
    last_ts: datetime | None
    category: str | None
    example: str

    def merge(self, other: ErrorCluster) -> None:
        self.count += other.count
        if other.first_idx < self.first_idx:
            self.first_idx, self.first_ts = other.first_idx, other.first_ts
        if other.last_idx > self.last_idx:
            self.last_idx, self.last_ts, self.example = other.last_idx, other.last_ts, other.example


def cluster_errors(errors: list[_Line], similarity: float = 0.85, max_signatures: int = 200) -> list[ErrorCluster]:
    """Group errors by normalised signature, then merge near-duplicates (difflib ratio)."""
    exact: dict[str, ErrorCluster] = {}
    for ln in errors:
        sig = _signature(ln.raw)
        if sig in exact:
            exact[sig].merge(ErrorCluster(sig, 1, ln.idx, ln.idx, ln.ts, ln.ts, ln.category, ln.raw))
        else:
            exact[sig] = ErrorCluster(sig, 1, ln.idx, ln.idx, ln.ts, ln.ts, ln.category, ln.raw)

    ordered = sorted(exact.values(), key=lambda c: c.count, reverse=True)[:max_signatures]
    merged: list[ErrorCluster] = []
    for cluster in ordered:
        for rep in merged:
            matcher = SequenceMatcher(None, rep.signature, cluster.signature)
            if matcher.quick_ratio() >= similarity and matcher.ratio() >= similarity:
                rep.merge(cluster)
                break
        else:
            merged.append(cluster)
    return sorted(merged, key=lambda c: c.count, reverse=True)


# ----------------------------------------------------------------------------- temporal analysis
def temporal_analysis(errors: list[_Line], total_lines: int) -> dict[str, Any]:
    if not errors:
        return {"total_errors": 0, "trend": "none"}

    stamped = [e for e in errors if e.ts]
    per_minute: Counter[str] = Counter(e.ts.strftime("%Y-%m-%d %H:%M") for e in stamped if e.ts)
    peak_minute, peak_count = per_minute.most_common(1)[0] if per_minute else (None, 0)

    # Trend: compare error volume in the first vs. second half of the observed window.
    use_ts = len(stamped) == len(errors)
    keys = [e.ts.timestamp() if use_ts and e.ts else float(e.idx) for e in errors]
    trend = "insufficient-data"
    if len(keys) >= 4:
        mid = (min(keys) + max(keys)) / 2
        first_half = sum(1 for k in keys if k <= mid)
        second_half = len(keys) - first_half
        if second_half > first_half * 1.5:
            trend = "escalating"
        elif second_half < first_half * 0.5:
            trend = "subsiding"
        else:
            trend = "steady"

    return {
        "total_errors": len(errors),
        "error_ratio": round(len(errors) / max(total_lines, 1), 3),
        "first_error": errors[0].ts.isoformat() if errors[0].ts else None,
        "last_error": errors[-1].ts.isoformat() if errors[-1].ts else None,
        "peak_errors_per_minute": peak_count,
        "peak_minute": peak_minute,
        "trend": trend,
    }


# ----------------------------------------------------------------------------- failure correlation
@dataclass(frozen=True)
class Correlation:
    cause: str
    effect: str
    lag_seconds: float | None
    strength: float

    def __str__(self) -> str:
        lag = f" (+{self.lag_seconds:.0f}s)" if self.lag_seconds is not None else ""
        return f"{self.cause} -> {self.effect}{lag} strength={self.strength:.2f}"


def correlate_failures(
    lines: list[_Line], window_seconds: float = 120.0, window_lines: int = 100
) -> list[Correlation]:
    """Heuristic cascade detection.

    Category A is a candidate cause of B when A first appears before B, B first appears within a
    short window, and A is not ranked as a more 'symptom-like' category than B.
    """
    first: dict[str, _Line] = {}
    for ln in lines:
        if ln.category and ln.category not in first:
            first[ln.category] = ln

    found: list[Correlation] = []
    for a, la in first.items():
        for b, lb in first.items():
            if a == b or la.idx >= lb.idx:
                continue
            if _PATTERN_BY_CATEGORY[a].symptom_rank > _PATTERN_BY_CATEGORY[b].symptom_rank:
                continue
            if la.ts and lb.ts:
                lag = (lb.ts - la.ts).total_seconds()
                if lag > window_seconds:
                    continue
                proximity = 1 - lag / window_seconds
            else:
                gap = lb.idx - la.idx
                if gap > window_lines:
                    continue
                lag, proximity = None, 1 - gap / window_lines
            found.append(Correlation(a, b, lag, round(0.3 + 0.7 * proximity, 2)))
    return sorted((c for c in found if c.strength >= 0.5), key=lambda c: c.strength, reverse=True)[:5]


# ----------------------------------------------------------------------------- analyzer
class LogAnalyzer:
    """Stateless analyzer; safe to share across concurrent incidents."""

    def analyze(self, service_name: str, lines: list[str]) -> AnalysisReport:
        if not lines:
            return AnalysisReport(
                service=service_name, root_cause="No log lines were available for analysis",
                confidence=0.1, category=UNKNOWN, recommended_action="Verify log paths and permissions",
                sources=["regex"],
            )

        parsed = _parse_lines(lines)
        errors = [ln for ln in parsed if ln.is_error]
        clusters = cluster_errors(errors)
        temporal = temporal_analysis(errors, len(parsed))
        correlations = correlate_failures(parsed)

        categorised = [ln for ln in parsed if ln.category]
        if not categorised:
            return AnalysisReport(
                service=service_name,
                root_cause=f"No known failure pattern detected in the last {len(lines)} log lines",
                confidence=0.2, category=UNKNOWN, recommended_action="Manual investigation required",
                evidence=[ln.raw[:300] for ln in errors[-3:]],
                clusters=self._cluster_dicts(clusters), temporal=temporal, sources=["regex"],
            )

        scores = self._score(parsed, categorised, correlations)
        best_cat, best_score = max(scores.items(), key=lambda kv: kv[1])
        pattern = _PATTERN_BY_CATEGORY[best_cat]
        count = sum(1 for ln in categorised if ln.category == best_cat)

        return AnalysisReport(
            service=service_name,
            root_cause=f"{pattern.root_cause} [{count} matching events]",
            confidence=self._confidence(best_score, sum(scores.values())),
            evidence=self._evidence(categorised, best_cat),
            category=best_cat,
            recoverable=pattern.recoverable,
            recommended_action=pattern.recommended_action,
            clusters=self._cluster_dicts(clusters),
            temporal=temporal,
            correlations=[str(c) for c in correlations],
            sources=["regex"],
        )

    @staticmethod
    def _score(parsed: list[_Line], categorised: list[_Line], correlations: list[Correlation]) -> dict[str, float]:
        total = max(len(parsed), 1)
        scores: dict[str, float] = defaultdict(float)
        for ln in categorised:
            assert ln.category
            recency = 0.5 + 0.5 * (ln.idx / total)  # later lines are closer to the moment the service stopped
            scores[ln.category] += ln.weight * _LEVEL_WEIGHT.get(ln.level, 0.8) * recency

        # The category of the final matching line is the most likely terminal failure.
        scores[categorised[-1].category] *= 1.25  # type: ignore[index]

        for corr in correlations:  # upstream causes of a cascade get a boost
            if corr.cause in scores:
                scores[corr.cause] *= 1 + 0.3 * corr.strength

        for cat in list(scores):  # symptoms (e.g. "failed to start") rarely are the root cause
            scores[cat] *= 1 - 0.1 * _PATTERN_BY_CATEGORY[cat].symptom_rank
        return dict(scores)

    @staticmethod
    def _confidence(best: float, total: float) -> float:
        dominance = best / total if total else 0.0
        volume = 1 - math.exp(-best / 3)
        return round(min(0.97, 0.35 + 0.6 * (0.6 * dominance + 0.4 * volume)), 2)

    @staticmethod
    def _evidence(categorised: list[_Line], category: str, limit: int = 5) -> list[str]:
        seen: set[str] = set()
        picked: list[str] = []
        for ln in reversed(categorised):  # newest first, one line per distinct signature
            if ln.category != category:
                continue
            sig = _signature(ln.raw)
            if sig in seen:
                continue
            seen.add(sig)
            picked.append(ln.raw[:300])
            if len(picked) >= limit:
                break
        return list(reversed(picked))

    @staticmethod
    def _cluster_dicts(clusters: list[ErrorCluster], limit: int = 5) -> list[dict[str, Any]]:
        return [
            {
                "signature": c.signature[:160], "count": c.count, "category": c.category,
                "first_seen": c.first_ts.isoformat() if c.first_ts else None,
                "last_seen": c.last_ts.isoformat() if c.last_ts else None,
            }
            for c in clusters[:limit]
        ]

    # ------------------------------------------------------------------ RAG integration
    @staticmethod
    def build_rag_query(report: AnalysisReport) -> str:
        parts = [f"Service: {report.service}", f"Category: {report.category}"]
        parts += [c["signature"] for c in report.clusters[:5]]
        parts += report.evidence[:3]
        return "\n".join(parts)

    @staticmethod
    def apply_rag_hits(report: AnalysisReport, hits: list[RagHit]) -> AnalysisReport:
        """Merge knowledge-base evidence into the regex result (logs -> runbook -> root cause -> remediation)."""
        if not hits:
            return report
        report.sources.append("rag")
        agreeing = [h for h in hits if h.category == report.category]

        if report.category != UNKNOWN:
            if agreeing:
                top = agreeing[0]
                report.confidence = round(min(0.99, report.confidence + (1 - report.confidence) * 0.4 * top.score), 2)
                runbook = next((h for h in agreeing if h.doc_type == "runbook"), None)
                if runbook:
                    report.runbook = runbook.source
                    if runbook.recoverable is not None:  # the runbook is authoritative on restart safety
                        report.recoverable = runbook.recoverable
                report.suggested_resolution = (top.resolution or top.content)[:600]
            elif hits[0].score >= 0.6:
                report.confidence = round(report.confidence * 0.9, 2)  # KB disagrees: be less certain
            return report

        # Regex found nothing: fall back to the best KB match.
        top = hits[0]
        if top.category:
            report.category = top.category
            report.root_cause = f"{top.root_cause or top.title} (inferred from knowledge base: {top.source})"
            report.confidence = round(min(0.6, top.score * 0.8), 2)
            report.runbook = top.source if top.doc_type == "runbook" else None
            report.recoverable = bool(top.recoverable) if top.doc_type == "runbook" else False
            report.suggested_resolution = (top.resolution or top.content)[:600]
            report.recommended_action = top.resolution or report.recommended_action
        return report
