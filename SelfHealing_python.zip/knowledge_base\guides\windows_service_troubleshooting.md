---
title: Windows Service Troubleshooting Guide
---
## General checklist
- Confirm the service state: `Get-Service <name>`; recovery options: `sc.exe qfailure <name>`.
- Check the Windows Event Log: `Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='Service Control Manager'} -MaxEvents 20`.
- Verify dependencies: `Get-Service <name> -DependentServices` and `-RequiredServices`.
- Confirm the Log On account has "Log on as a service" rights and access to required shares.
- Review application logs on the shared log path for the first error before the stop.

## Restart policy
Restart only when the cause is transient (network, database, memory, port, startup). Do not restart for credential, certificate or file permission problems; fix them first.
