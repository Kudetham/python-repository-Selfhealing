---
title: SSL Certificate Runbook
category: SSL_CERTIFICATE
recoverable: false
root_cause: TLS certificate expired, untrusted or mismatched
---
## Symptoms
Certificate has expired, CERTIFICATE_VERIFY_FAILED, "The remote certificate is invalid", could not establish trust relationship for the SSL/TLS secure channel.

## Diagnosis
1. `Get-ChildItem Cert:\LocalMachine\My | Select Subject, NotAfter, Thumbprint`.
2. Verify the full chain and the root CA in `Cert:\LocalMachine\Root`.

## Resolution
Renew and re-bind the certificate, then restart the service. Restarting before renewal does not help.
