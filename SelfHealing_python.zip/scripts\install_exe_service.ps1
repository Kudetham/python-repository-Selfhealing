<#
.SYNOPSIS
  Installs the packaged SelfHealingAgent.exe as a Windows service. Run elevated, from the folder that holds the exe and .env.
.PARAMETER ServiceAccount
  Optional gMSA (e.g. 'CONTOSO\svc-selfheal$'). Default is LocalSystem - NOT recommended for production.
#>
[CmdletBinding()]
param(
    [string]$ServiceAccount,
    [int]$Port = 8080,
    [string]$DataRoot = 'C:\SelfHealingAgent',
    [switch]$OpenFirewall
)

$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $identity.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run this script as Administrator.' }

$Dir = $PSScriptRoot
$Exe = Join-Path $Dir 'SelfHealingAgent.exe'
$SvcName = 'SelfHealingAgent'
if (-not (Test-Path $Exe)) { throw "SelfHealingAgent.exe not found in $Dir" }
if (-not (Test-Path (Join-Path $Dir '.env'))) { throw ".env not found in $Dir. Copy .env.example to .env and configure it first." }

New-Item -ItemType Directory -Force -Path "$DataRoot\Logs", "$DataRoot\Index" | Out-Null

& $Exe --startup auto install
if ($LASTEXITCODE -ne 0) { throw 'Service install failed' }

if ($ServiceAccount) {
    sc.exe config $SvcName obj= $ServiceAccount password= '""' | Out-Null
    icacls "$DataRoot" /grant "${ServiceAccount}:(OI)(CI)M" | Out-Null
}
sc.exe failure $SvcName reset= 86400 actions= restart/60000/restart/60000/restart/60000 | Out-Null

if ($OpenFirewall) {
    New-NetFirewallRule -DisplayName 'SelfHealingAgent Webhook' -Direction Inbound -Protocol TCP `
        -LocalPort $Port -Action Allow -Profile Domain | Out-Null
}

Start-Service $SvcName
Get-Service $SvcName | Format-Table Name, Status, StartType -AutoSize
