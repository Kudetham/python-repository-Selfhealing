<#
.SYNOPSIS
  Runs the agent in the foreground for development (no Windows service).
#>
$AppRoot = Split-Path -Parent $PSScriptRoot
Set-Location $AppRoot
& (Join-Path $AppRoot '.venv\Scripts\python.exe') -m uvicorn app.main:app --host 127.0.0.1 --port 8080
