"""POST /grafana-alert endpoint."""
from __future__ import annotations

import logging
import uuid
from typing import TYPE_CHECKING

from fastapi import APIRouter, BackgroundTasks, Depends, Request, status

from app.logging_setup import audit, incident_id_var
from app.models import AcceptedResponse, GrafanaAlert
from app.security import verify_api_key

if TYPE_CHECKING:
    from app.incident_agent import IncidentAgent

logger = logging.getLogger("selfhealing.webhook")

# Auth is a dependency, so a bad key yields 401 before body validation errors are reported.
router = APIRouter(tags=["grafana"], dependencies=[Depends(verify_api_key)])

# Grafana re-sends firing alerts; this prevents concurrent duplicate remediation for the same service.
# Valid because the app runs a single event loop / single worker process.
_in_flight: set[tuple[str, str]] = set()


async def _run_incident(agent: IncidentAgent, alert: GrafanaAlert, incident_id: str, key: tuple[str, str]) -> None:
    incident_id_var.set(incident_id)
    try:
        await agent.handle(alert, incident_id)
    except Exception:  # noqa: BLE001 - background task: log, never crash the worker
        logger.exception("incident_failed")
    finally:
        _in_flight.discard(key)


@router.post("/grafana-alert", response_model=AcceptedResponse, status_code=status.HTTP_202_ACCEPTED)
async def grafana_alert(alert: GrafanaAlert, request: Request, background: BackgroundTasks) -> AcceptedResponse:
    incident_id = uuid.uuid4().hex[:12]
    incident_id_var.set(incident_id)
    client = request.client.host if request.client else "unknown"

    logger.info("grafana_alert_received", extra={"client": client, "alert": alert.model_dump(mode="json")})
    audit("alert_received", incident_id=incident_id, client=client, server=alert.server_name,
          service=alert.service_name, alert=alert.alert_name)

    key = (alert.server_name.lower(), alert.service_name.lower())
    if key in _in_flight:
        logger.info("duplicate_alert_ignored")
        return AcceptedResponse(incident_id=incident_id, status="already_in_progress")

    _in_flight.add(key)
    # The 30s post-restart wait makes processing long; reply to Grafana immediately.
    background.add_task(_run_incident, request.app.state.agent, alert, incident_id, key)
    return AcceptedResponse(incident_id=incident_id, status="accepted")
