---
title: Port Conflict Runbook
category: PORT_CONFLICT
recoverable: true
root_cause: Listening port held by another or stale process
---
## Symptoms
"Address already in use", "Only one usage of each socket address", SocketException 10048, failed to bind.

## Diagnosis
1. `Get-NetTCPConnection -LocalPort <port> | Select OwningProcess`, then `Get-Process -Id <pid>`.
2. Check for a hung previous instance of the same service.

## Resolution
Restart the service (stale instance is released on stop). If another application owns the port, reassign one of the ports and escalate.
