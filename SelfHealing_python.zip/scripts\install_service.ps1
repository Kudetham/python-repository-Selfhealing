<#
.SYNOPSIS
  Installs the Self-Healing Agent as a Windows service. Run from an elevated PowerShell prompt.
.PARAMETER ServiceAccount
  Optional gMSA (e.g. 'CONTOSO\svc-selfheal$'). Default is LocalSystem - NOT recommended for production.
#>
[CmdletBinding()]
param(
    [string]$ServiceAccount,
    [int]$Port = 8080,
    [string]$DataRoot = 'C:\SelfHealingAgent',
    [switch]$OpenFirewall
)

$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $identity.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this script as Administrator.'
}

$AppRoot = Split-Path -Parent $PSScriptRoot
$Venv    = Join-Path $AppRoot '.venv'
$Py      = Join-Path $Venv 'Scripts\python.exe'
$SvcName = 'SelfHealingAgent'

if (-not (Test-Path (Join-Path $AppRoot '.env'))) {
    throw ".env not found in $AppRoot. Copy .env.example to .env and configure it first."
}

Write-Host '==> Creating data directories'
New-Item -ItemType Directory -Force -Path "$DataRoot\Logs", "$DataRoot\Index" | Out-Null

Write-Host '==> Creating Python 3.11 virtual environment'
if (-not (Test-Path $Py)) { & py -3.11 -m venv $Venv }
& $Py -m pip install --upgrade pip
& $Py -m pip install -r (Join-Path $AppRoot 'requirements.txt')
& $Py (Join-Path $Venv 'Scripts\pywin32_postinstall.py') -install

Write-Host '==> Registering Windows service'
& $Py (Join-Path $AppRoot 'windows_service\selfhealing_service.py') --startup auto install

if ($ServiceAccount) {
    # gMSA: empty password; Windows retrieves it from AD.
    sc.exe config $SvcName obj= $ServiceAccount password= '""' | Out-Null
    icacls "$DataRoot" /grant "${ServiceAccount}:(OI)(CI)M" | Out-Null
}

# Restart the agent itself automatically if it crashes (3 retries, 60s apart; counter resets after 1 day).
sc.exe failure $SvcName reset= 86400 actions= restart/60000/restart/60000/restart/60000 | Out-Null

if ($OpenFirewall) {
    New-NetFirewallRule -DisplayName 'SelfHealingAgent Webhook' -Direction Inbound -Protocol TCP `
        -LocalPort $Port -Action Allow -Profile Domain | Out-Null
}

Write-Host '==> Starting service'
Start-Service $SvcName
Get-Service $SvcName | Format-Table Name, Status, StartType -AutoSize
