"""Local RAG knowledge base: LangChain + FAISS + Azure OpenAI embeddings.

Workflow: logs -> vector search -> relevant runbook / past incident -> root-cause suggestion -> remediation.
If Azure OpenAI is not configured or the index cannot be built, the engine disables itself and the
agent continues with regex analysis only (self-healing must not depend on the AI service).
"""
from __future__ import annotations

import hashlib
import json
import logging
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.config import Settings

logger = logging.getLogger("selfhealing.rag")

_MANIFEST = "manifest.json"
_MAX_QUERY_CHARS = 6000  # stay well below the embedding model token limit
_AUTO_INCIDENTS_FILE = "auto_recorded.jsonl"


@dataclass(frozen=True)
class RagHit:
    content: str
    source: str
    doc_type: str  # runbook | incident | guide
    category: str | None
    score: float  # cosine similarity in [0, 1]
    recoverable: bool | None
    title: str
    root_cause: str | None
    resolution: str | None


def _parse_front_matter(text: str) -> tuple[dict[str, str], str]:
    """Minimal ``key: value`` front matter parser (avoids a YAML dependency)."""
    if not text.startswith("---"):
        return {}, text
    end = text.find("\n---", 3)
    if end == -1:
        return {}, text
    meta: dict[str, str] = {}
    for line in text[3:end].splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            meta[key.strip().lower()] = value.strip()
    return meta, text[end + 4:].lstrip()


def _to_bool(value: str | None) -> bool | None:
    if value is None:
        return None
    return {"true": True, "false": False}.get(value.strip().lower())


class RagEngine:
    def __init__(self, settings: Settings) -> None:
        self._s = settings
        self._store: Any = None
        self._embeddings: Any = None
        self._lock = threading.RLock()

    @property
    def enabled(self) -> bool:
        return self._store is not None

    # ------------------------------------------------------------------ lifecycle
    def initialize(self) -> None:
        """Load the FAISS index, rebuilding it when the knowledge base changed."""
        if not self._s.rag_configured:
            logger.warning("rag_disabled_not_configured")
            return
        try:
            from langchain_community.vectorstores import FAISS
            from langchain_openai import AzureOpenAIEmbeddings

            self._embeddings = AzureOpenAIEmbeddings(
                azure_endpoint=self._s.azure_openai_endpoint,
                api_key=self._s.azure_openai_api_key,  # SecretStr accepted by langchain-openai
                api_version=self._s.azure_openai_api_version,
                azure_deployment=self._s.azure_openai_embedding_deployment,
                model=self._s.azure_openai_embedding_deployment,
                max_retries=3,
                timeout=30,
            )
            index_dir = self._s.rag_index_dir
            index_dir.mkdir(parents=True, exist_ok=True)
            fingerprint = self._fingerprint()

            if self._manifest_matches(index_dir, fingerprint) and (index_dir / "index.faiss").exists():
                # The pickle in the index is produced by this service only; keep the index dir ACL-restricted.
                self._store = FAISS.load_local(str(index_dir), self._embeddings, allow_dangerous_deserialization=True)
                logger.info("rag_index_loaded", extra={"index_dir": str(index_dir)})
                return

            docs = self._load_documents()
            if not docs:
                logger.warning("rag_disabled_empty_knowledge_base", extra={"kb_dir": str(self._s.kb_dir)})
                return
            self._store = FAISS.from_documents(docs, self._embeddings)
            self._store.save_local(str(index_dir))
            self._write_manifest(index_dir, fingerprint)
            logger.info("rag_index_built", extra={"documents": len(docs)})
        except Exception:  # noqa: BLE001 - RAG is optional; never block startup
            logger.exception("rag_initialisation_failed")
            self._store = None

    # ------------------------------------------------------------------ search
    def search(self, query: str, top_k: int | None = None) -> list[RagHit]:
        if not self.enabled:
            return []
        k = top_k or self._s.rag_top_k
        try:
            with self._lock:
                results = self._store.similarity_search_with_score(query[:_MAX_QUERY_CHARS], k=k)
        except Exception:  # noqa: BLE001
            logger.exception("rag_search_failed")
            return []

        hits: list[RagHit] = []
        for doc, distance in results:
            # OpenAI embeddings are unit length and FAISS returns squared L2, so cosine = 1 - d/2.
            score = max(0.0, min(1.0, 1 - float(distance) / 2))
            if score < self._s.rag_min_score:
                continue
            m = doc.metadata
            hits.append(RagHit(
                content=doc.page_content, source=m.get("source", "unknown"), doc_type=m.get("doc_type", "guide"),
                category=m.get("category") or None, score=round(score, 3), recoverable=m.get("recoverable"),
                title=m.get("title", ""), root_cause=m.get("root_cause"), resolution=m.get("resolution"),
            ))
        return hits

    # ------------------------------------------------------------------ learning loop
    def record_incident(self, *, server: str, service: str, category: str, root_cause: str,
                        action_taken: str, outcome: str, evidence: list[str]) -> None:
        """Append the resolved incident to the knowledge base so future searches can reuse it."""
        entry = {
            "id": f"AUTO-{datetime.now(timezone.utc):%Y%m%d%H%M%S}", "service": service, "server": server,
            "category": category, "symptoms": " | ".join(evidence[:3])[:600], "root_cause": root_cause,
            "resolution": f"{action_taken} (outcome: {outcome})",
        }
        path = self._s.kb_dir / "incidents" / _AUTO_INCIDENTS_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        with self._lock:
            with path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
            if self.enabled:
                try:
                    self._store.add_documents([self._incident_doc(entry, _AUTO_INCIDENTS_FILE)])
                    self._store.save_local(str(self._s.rag_index_dir))
                    self._write_manifest(self._s.rag_index_dir, self._fingerprint())
                except Exception:  # noqa: BLE001
                    logger.exception("rag_incident_index_failed")

    # ------------------------------------------------------------------ document loading
    def _load_documents(self) -> list[Any]:
        from langchain_core.documents import Document
        from langchain_text_splitters import RecursiveCharacterTextSplitter

        kb = self._s.kb_dir
        splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=150)
        docs: list[Document] = []

        for folder, doc_type in (("runbooks", "runbook"), ("guides", "guide")):
            for path in sorted((kb / folder).glob("*.md")):
                meta, body = _parse_front_matter(path.read_text(encoding="utf-8-sig"))
                base = {
                    "source": f"{folder}/{path.name}", "doc_type": doc_type,
                    "title": meta.get("title", path.stem), "category": meta.get("category", ""),
                    "root_cause": meta.get("root_cause", ""),
                }
                if (rec := _to_bool(meta.get("recoverable"))) is not None:
                    base["recoverable"] = rec
                for chunk in splitter.split_text(body):
                    docs.append(Document(page_content=f"{base['title']}\n{chunk}", metadata=dict(base)))

        incidents_dir = kb / "incidents"
        for path in sorted(incidents_dir.glob("*.json")):
            for entry in json.loads(path.read_text(encoding="utf-8-sig")):
                docs.append(self._incident_doc(entry, path.name))
        for path in sorted(incidents_dir.glob("*.jsonl")):
            for line in path.read_text(encoding="utf-8-sig").splitlines():
                if line.strip():
                    docs.append(self._incident_doc(json.loads(line), path.name))
        return docs

    @staticmethod
    def _incident_doc(entry: dict[str, Any], source_file: str) -> Any:
        from langchain_core.documents import Document

        text = (
            f"Incident {entry.get('id', '?')}: service {entry.get('service', '?')}. "
            f"Symptoms: {entry.get('symptoms', '')}. Root cause: {entry.get('root_cause', '')}. "
            f"Resolution: {entry.get('resolution', '')}"
        )
        meta = {
            "source": f"incidents/{source_file}", "doc_type": "incident", "title": str(entry.get("id", "")),
            "category": entry.get("category", ""), "root_cause": entry.get("root_cause", ""),
            "resolution": entry.get("resolution", ""),
        }
        return Document(page_content=text, metadata=meta)

    # ------------------------------------------------------------------ change detection
    def _fingerprint(self) -> str:
        digest = hashlib.sha256(self._s.azure_openai_embedding_deployment.encode())
        for path in sorted(p for p in self._s.kb_dir.rglob("*") if p.is_file()):
            st = path.stat()
            digest.update(f"{path.relative_to(self._s.kb_dir)}|{st.st_size}|{st.st_mtime_ns}".encode())
        return digest.hexdigest()

    @staticmethod
    def _manifest_matches(index_dir: Path, fingerprint: str) -> bool:
        try:
            return json.loads((index_dir / _MANIFEST).read_text())["fingerprint"] == fingerprint
        except (OSError, KeyError, ValueError):
            return False

    @staticmethod
    def _write_manifest(index_dir: Path, fingerprint: str) -> None:
        (index_dir / _MANIFEST).write_text(json.dumps({"fingerprint": fingerprint}))
