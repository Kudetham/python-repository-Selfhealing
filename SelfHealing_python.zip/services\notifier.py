"""Microsoft Teams notifications using an Adaptive Card posted to a Teams webhook."""
from __future__ import annotations

import logging
from typing import Any

import httpx
from tenacity import AsyncRetrying, retry_if_exception, stop_after_attempt, wait_exponential

from app.config import Settings
from app.models import IncidentResult, RemediationStatus

logger = logging.getLogger("selfhealing.notifier")


def _is_transient(exc: BaseException) -> bool:
    if isinstance(exc, httpx.TransportError):
        return True
    return isinstance(exc, httpx.HTTPStatusError) and exc.response.status_code in (429, 500, 502, 503, 504)


def _trim(text: str, limit: int) -> str:
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _facts(pairs: list[tuple[str, str]]) -> dict[str, Any]:
    return {"type": "FactSet", "facts": [{"title": k, "value": _trim(v, 300)} for k, v in pairs]}


def _section(title: str) -> dict[str, Any]:
    return {"type": "TextBlock", "text": title, "weight": "Bolder", "size": "Medium", "separator": True, "spacing": "Medium"}


class TeamsNotifier:
    def __init__(self, settings: Settings) -> None:
        self._s = settings

    def build_card(self, r: IncidentResult) -> dict[str, Any]:
        ok = r.remediation_status == RemediationStatus.SUCCESS
        colour = "Good" if ok else "Attention"
        a = r.analysis

        body: list[dict[str, Any]] = [
            {"type": "TextBlock", "size": "Large", "weight": "Bolder", "color": colour, "wrap": True,
             "text": f"Self-Healing: {r.alert.service_name} on {r.alert.server_name} - {r.remediation_status.value}"},
            _section("Alert Received"),
            _facts([
                ("Alert", r.alert.alert_name),
                ("Server Name", r.alert.server_name),
                ("Service Name", r.alert.service_name),
                ("Alert Time", r.alert.timestamp.isoformat()),
                ("Incident ID", r.incident_id),
            ]),
            _section("Root Cause"),
            {"type": "TextBlock", "wrap": True, "text": _trim(a.root_cause, 500)},
            _facts([("Category", a.category), ("Confidence", f"{a.confidence:.0%}")]),
        ]
        if a.evidence:
            body.append({
                "type": "TextBlock", "wrap": True, "fontType": "Monospace", "size": "Small",
                "text": "\n\n".join(_trim(e, 250) for e in a.evidence[:3]),
            })
        body += [
            _section("Remediation Performed"),
            {"type": "TextBlock", "wrap": True, "text": _trim(r.action_taken, 500)},
            _section("Final Status"),
            _facts([
                ("Service Status", r.service_status),
                ("Remediation Status", r.remediation_status.value),
                ("Time Taken", f"{r.time_taken_seconds:.1f}s"),
            ]),
        ]
        if a.runbook:
            body.append({"type": "TextBlock", "isSubtle": True, "size": "Small", "text": f"Runbook: {a.runbook}"})

        return {
            "type": "message",
            "attachments": [{
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": None,
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard", "version": "1.4", "body": body,
                },
            }],
        }

    async def send_incident(self, result: IncidentResult) -> bool:
        """Returns True on success. Never raises: a notification failure must not fail remediation."""
        url = self._s.teams_webhook_url
        if url is None:
            logger.warning("teams_not_configured")
            return False
        card = self.build_card(result)
        try:
            async with httpx.AsyncClient(timeout=self._s.teams_timeout_seconds) as client:
                async for attempt in AsyncRetrying(
                    stop=stop_after_attempt(self._s.teams_max_retries),
                    wait=wait_exponential(multiplier=2, min=2, max=20),
                    retry=retry_if_exception(_is_transient),
                    reraise=True,
                ):
                    with attempt:
                        resp = await client.post(url.get_secret_value(), json=card)
                        resp.raise_for_status()
            logger.info("teams_notification_sent")
            return True
        except Exception as exc:  # noqa: BLE001
            # Log type/status only: httpx error text contains the secret webhook URL.
            status = exc.response.status_code if isinstance(exc, httpx.HTTPStatusError) else None
            logger.error("teams_notification_failed", extra={"error": type(exc).__name__, "http_status": status})
            return False
