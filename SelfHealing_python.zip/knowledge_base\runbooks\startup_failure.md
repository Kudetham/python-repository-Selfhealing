---
title: Service Startup Failure Runbook
category: STARTUP_FAILURE
recoverable: true
root_cause: Service terminated during startup (often a downstream symptom of another failure)
---
## Symptoms
"Failed to start", "Service terminated unexpectedly", Error 1053 (timeout waiting for service to respond), unhandled exception at startup.

## Diagnosis
1. Look at the first error in the failure chain; startup failure is frequently the final symptom.
2. Check the Windows Event Log (Application, Service Control Manager 7000/7009/7031).

## Resolution
Restart once. If it stops again, treat the earlier error in the log (database, network, certificate) as the real root cause.
