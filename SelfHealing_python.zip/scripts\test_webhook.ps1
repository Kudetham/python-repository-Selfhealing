<#
.SYNOPSIS
  Sends a sample Grafana alert to the agent. Reads the API key from the SH_API_KEY environment variable.
.EXAMPLE
  $env:SH_API_KEY = '<key>'; .\test_webhook.ps1 -Server APP-SRV-01 -Service MyAppService
#>
param(
    [string]$Url = 'http://localhost:8000/grafana-alert',
    [Parameter(Mandatory)][string]$Server,
    [Parameter(Mandatory)][string]$Service,
    [string]$AlertName = 'Windows Service Stopped'
)

$body = @{
    server_name  = $Server
    service_name = $Service
    alert_name   = $AlertName
    timestamp    = (Get-Date).ToUniversalTime().ToString('o')
} | ConvertTo-Json

Invoke-RestMethod -Method Post -Uri $Url -Body $body -ContentType 'application/json' `
    -Headers @{ 'X-API-Key' = $env:SH_API_KEY }
