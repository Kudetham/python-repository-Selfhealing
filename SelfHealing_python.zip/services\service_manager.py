"""Windows service control via pywin32, with a PowerShell fallback.

Public API (synchronous; call through ``asyncio.to_thread`` from async code):
    get_service_status, start_service, stop_service, restart_service
"""
from __future__ import annotations

import logging
import os
import socket
import subprocess
import sys
from dataclasses import dataclass
from enum import Enum

from tenacity import (
    retry,
    retry_if_exception_type,
    retry_if_not_exception_type,
    stop_after_attempt,
    wait_fixed,
)

from app.config import get_settings

logger = logging.getLogger("selfhealing.service_manager")

try:  # pywin32 only exists on Windows
    import pywintypes
    import win32service
    import win32serviceutil

    HAS_PYWIN32 = True
except ImportError:  # pragma: no cover - non-Windows dev machines
    HAS_PYWIN32 = False

_ERROR_SERVICE_DOES_NOT_EXIST = 1060
_ERROR_SERVICE_ALREADY_RUNNING = 1056
_ERROR_SERVICE_NOT_ACTIVE = 1062


class ServiceState(str, Enum):
    RUNNING = "Running"
    STOPPED = "Stopped"
    START_PENDING = "StartPending"
    STOP_PENDING = "StopPending"
    PAUSED = "Paused"
    PAUSE_PENDING = "PausePending"
    CONTINUE_PENDING = "ContinuePending"
    NOT_FOUND = "NotFound"
    UNKNOWN = "Unknown"


class ServiceControlError(RuntimeError):
    """Raised when a service operation fails (retried by the public functions)."""


class ServiceNotFoundError(ServiceControlError):
    """The service does not exist on the target machine (never retried)."""


@dataclass(frozen=True)
class ServiceOperationResult:
    success: bool
    state: ServiceState
    message: str


_retry_control = retry(
    stop=stop_after_attempt(3),
    wait=wait_fixed(2),
    retry=retry_if_exception_type(ServiceControlError) & retry_if_not_exception_type(ServiceNotFoundError),
    reraise=True,
)


def _target_machine(server_name: str | None) -> str | None:
    """None means the local machine."""
    if not server_name:
        return None
    local = socket.gethostname().lower()
    name = server_name.lower()
    if name in (local, "localhost", "127.0.0.1") or name.split(".")[0] == local:
        return None
    return server_name


def _use_pywin32() -> bool:
    backend = get_settings().service_backend
    if backend == "pywin32":
        if not HAS_PYWIN32:
            raise ServiceControlError("pywin32 backend requested but pywin32 is not installed")
        return True
    if backend == "powershell":
        return False
    return HAS_PYWIN32


# ----------------------------------------------------------------------------- pywin32 backend
def _pw_state(name: str, machine: str | None) -> ServiceState:
    state_map = {
        win32service.SERVICE_RUNNING: ServiceState.RUNNING,
        win32service.SERVICE_STOPPED: ServiceState.STOPPED,
        win32service.SERVICE_START_PENDING: ServiceState.START_PENDING,
        win32service.SERVICE_STOP_PENDING: ServiceState.STOP_PENDING,
        win32service.SERVICE_PAUSED: ServiceState.PAUSED,
        win32service.SERVICE_PAUSE_PENDING: ServiceState.PAUSE_PENDING,
        win32service.SERVICE_CONTINUE_PENDING: ServiceState.CONTINUE_PENDING,
    }
    try:
        status = win32serviceutil.QueryServiceStatus(name, machine)
    except pywintypes.error as exc:
        if exc.winerror == _ERROR_SERVICE_DOES_NOT_EXIST:
            raise ServiceNotFoundError(f"Service '{name}' not found") from exc
        raise ServiceControlError(f"Status query failed ({exc.winerror}): {exc.strerror}") from exc
    return state_map.get(status[1], ServiceState.UNKNOWN)


def _pw_stop(name: str, machine: str | None, timeout: int) -> None:
    try:
        win32serviceutil.StopService(name, machine)
    except pywintypes.error as exc:
        if exc.winerror == _ERROR_SERVICE_DOES_NOT_EXIST:
            raise ServiceNotFoundError(f"Service '{name}' not found") from exc
        if exc.winerror != _ERROR_SERVICE_NOT_ACTIVE:
            raise ServiceControlError(f"Stop failed ({exc.winerror}): {exc.strerror}") from exc
    try:
        win32serviceutil.WaitForServiceStatus(name, win32service.SERVICE_STOPPED, timeout, machine)
    except pywintypes.error as exc:
        raise ServiceControlError(f"Service did not stop within {timeout}s: {exc.strerror}") from exc


def _pw_start(name: str, machine: str | None) -> None:
    try:
        win32serviceutil.StartService(name, None, machine)
    except pywintypes.error as exc:
        if exc.winerror == _ERROR_SERVICE_DOES_NOT_EXIST:
            raise ServiceNotFoundError(f"Service '{name}' not found") from exc
        if exc.winerror != _ERROR_SERVICE_ALREADY_RUNNING:
            raise ServiceControlError(f"Start failed ({exc.winerror}): {exc.strerror}") from exc


# ----------------------------------------------------------------------------- PowerShell backend
# Only these fixed cmdlets are ever executed. The service/server names travel through
# environment variables, never string interpolation, so they cannot inject PowerShell code.
_PS_ACTIONS = {
    "status": "(Get-Service -Name $n -ErrorAction Stop).Status.ToString()",
    "start": "Start-Service -Name $n -ErrorAction Stop",
    "stop": "Stop-Service -Name $n -Force -ErrorAction Stop",
    "restart": "Restart-Service -Name $n -Force -ErrorAction Stop",
}


def _run_powershell(action: str, name: str, machine: str | None) -> str:
    body = _PS_ACTIONS[action]
    script = (
        "$ErrorActionPreference='Stop';"
        "$n=$env:SH_SVC_NAME;$srv=$env:SH_SVC_SERVER;"
        f"$sb={{ param($n) {body} }};"
        "if($srv){Invoke-Command -ComputerName $srv -ScriptBlock $sb -ArgumentList $n}else{& $sb $n}"
    )
    env = {**os.environ, "SH_SVC_NAME": name, "SH_SVC_SERVER": machine or ""}
    timeout = get_settings().service_op_timeout + 30
    try:
        proc = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True, text=True, timeout=timeout, env=env, check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ServiceControlError(f"PowerShell {action} failed: {type(exc).__name__}") from exc
    if proc.returncode != 0:
        err = (proc.stderr or proc.stdout).strip()
        if "Cannot find any service" in err or "was not found" in err:
            raise ServiceNotFoundError(f"Service '{name}' not found")
        raise ServiceControlError(f"PowerShell {action} failed: {err[:300]}")
    return proc.stdout.strip()


def _ps_state(name: str, machine: str | None) -> ServiceState:
    raw = _run_powershell("status", name, machine)
    try:
        return ServiceState(raw)
    except ValueError:
        return ServiceState.UNKNOWN


# ----------------------------------------------------------------------------- public API
def get_service_status(service_name: str, server_name: str | None = None) -> ServiceState:
    machine = _target_machine(server_name)
    return _pw_state(service_name, machine) if _use_pywin32() else _ps_state(service_name, machine)


@_retry_control
def start_service(service_name: str, server_name: str | None = None) -> ServiceOperationResult:
    """Issue a start request. Does not block until Running; callers poll the status."""
    machine = _target_machine(server_name)
    if _use_pywin32():
        _pw_start(service_name, machine)
    else:
        _run_powershell("start", service_name, machine)
    state = get_service_status(service_name, server_name)
    logger.info("service_start_requested", extra={"service": service_name, "server": server_name, "state": state.value})
    return ServiceOperationResult(True, state, "Start requested")


@_retry_control
def stop_service(service_name: str, server_name: str | None = None) -> ServiceOperationResult:
    """Stop the service and wait (up to ``service_op_timeout``) until it is Stopped."""
    machine = _target_machine(server_name)
    if _use_pywin32():
        _pw_stop(service_name, machine, get_settings().service_op_timeout)
    else:
        _run_powershell("stop", service_name, machine)
    state = get_service_status(service_name, server_name)
    logger.info("service_stopped", extra={"service": service_name, "server": server_name, "state": state.value})
    return ServiceOperationResult(state == ServiceState.STOPPED, state, "Stop completed")


@_retry_control
def restart_service(service_name: str, server_name: str | None = None) -> ServiceOperationResult:
    """Stop (if running) then start. The caller is responsible for the post-restart wait/verification."""
    machine = _target_machine(server_name)
    if _use_pywin32():
        if _pw_state(service_name, machine) != ServiceState.STOPPED:
            _pw_stop(service_name, machine, get_settings().service_op_timeout)
        _pw_start(service_name, machine)
    else:
        _run_powershell("restart", service_name, machine)
    state = get_service_status(service_name, server_name)
    logger.info("service_restarted", extra={"service": service_name, "server": server_name, "state": state.value})
    return ServiceOperationResult(True, state, "Restart requested")


if sys.platform != "win32":  # pragma: no cover
    logger.warning("service_manager_non_windows_platform")
